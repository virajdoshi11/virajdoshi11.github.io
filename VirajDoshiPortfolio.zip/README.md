# Hello

This is my portfolio website it contains information about my skills, projects
I made and my experience in Software Engineering.
This website is build with Node.js, HTML/CSS/JavaScript and Bootstrap.

# Contents

There are different sections for easy navigation like
1. About
2. Skills
3. Projects
4. Experience
5. Contact Info